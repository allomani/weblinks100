-- phpMyAdmin SQL Dump
-- version 2.9.0.1
-- http://www.phpmyadmin.net
-- 
-- Host: localhost
-- Generation Time: Dec 12, 2006 at 11:53 PM
-- Server version: 4.0.26
-- PHP Version: 5.1.2
-- 
-- Database: `weblinks`
-- 

-- --------------------------------------------------------

-- 
-- Table structure for table `info_best_visitors`
-- 

CREATE TABLE `info_best_visitors` (
  `time` text NOT NULL,
  `v_count` int(11) NOT NULL default '0'
) ;

-- 
-- Dumping data for table `info_best_visitors`
-- 

INSERT INTO `info_best_visitors` VALUES ('12-Dec-2005 ������ : 14:30', 1);

-- --------------------------------------------------------

-- 
-- Table structure for table `info_browser`
-- 

CREATE TABLE `info_browser` (
  `name` text NOT NULL,
  `count` int(11) NOT NULL default '0'
) ;

-- 
-- Dumping data for table `info_browser`
-- 

INSERT INTO `info_browser` VALUES ('Netscape', 64);
INSERT INTO `info_browser` VALUES ('MSIE', 5544);
INSERT INTO `info_browser` VALUES ('Lynx', 0);
INSERT INTO `info_browser` VALUES ('Opera', 0);
INSERT INTO `info_browser` VALUES ('WebTV', 0);
INSERT INTO `info_browser` VALUES ('Konqueror', 0);
INSERT INTO `info_browser` VALUES ('Bot', 0);
INSERT INTO `info_browser` VALUES ('Other', 3);

-- --------------------------------------------------------

-- 
-- Table structure for table `info_hits`
-- 

CREATE TABLE `info_hits` (
  `date` text NOT NULL,
  `hits` int(11) NOT NULL default '0'
) ;

-- 
-- Dumping data for table `info_hits`
-- 

INSERT INTO `info_hits` VALUES ('11-12-2005', 52);
INSERT INTO `info_hits` VALUES ('12-12-2005', 108);
INSERT INTO `info_hits` VALUES ('26-12-2005', 8);
INSERT INTO `info_hits` VALUES ('03-01-2006', 57);
INSERT INTO `info_hits` VALUES ('04-01-2006', 19);
INSERT INTO `info_hits` VALUES ('27-02-2006', 99);
INSERT INTO `info_hits` VALUES ('28-02-2006', 236);
INSERT INTO `info_hits` VALUES ('29-01-2006', 249);
INSERT INTO `info_hits` VALUES ('30-01-2006', 80);
INSERT INTO `info_hits` VALUES ('31-01-2006', 123);
INSERT INTO `info_hits` VALUES ('01-02-2006', 20);
INSERT INTO `info_hits` VALUES ('03-02-2006', 63);
INSERT INTO `info_hits` VALUES ('14-02-2006', 15);
INSERT INTO `info_hits` VALUES ('01-03-2006', 7);
INSERT INTO `info_hits` VALUES ('02-03-2006', 10);
INSERT INTO `info_hits` VALUES ('03-03-2006', 15);
INSERT INTO `info_hits` VALUES ('05-03-2006', 19);
INSERT INTO `info_hits` VALUES ('07-03-2006', 100);
INSERT INTO `info_hits` VALUES ('13-03-2006', 18);
INSERT INTO `info_hits` VALUES ('14-03-2006', 13);
INSERT INTO `info_hits` VALUES ('16-03-2006', 18);
INSERT INTO `info_hits` VALUES ('18-03-2006', 1);
INSERT INTO `info_hits` VALUES ('24-03-2006', 1);
INSERT INTO `info_hits` VALUES ('25-03-2006', 17);
INSERT INTO `info_hits` VALUES ('26-03-2006', 91);
INSERT INTO `info_hits` VALUES ('27-03-2006', 246);
INSERT INTO `info_hits` VALUES ('28-03-2006', 48);
INSERT INTO `info_hits` VALUES ('29-03-2006', 10);
INSERT INTO `info_hits` VALUES ('01-04-2006', 216);
INSERT INTO `info_hits` VALUES ('02-04-2006', 210);
INSERT INTO `info_hits` VALUES ('03-04-2006', 58);
INSERT INTO `info_hits` VALUES ('09-04-2006', 1);
INSERT INTO `info_hits` VALUES ('12-04-2006', 1);
INSERT INTO `info_hits` VALUES ('18-04-2006', 13);
INSERT INTO `info_hits` VALUES ('24-04-2006', 92);
INSERT INTO `info_hits` VALUES ('24-05-2006', 12);
INSERT INTO `info_hits` VALUES ('30-05-2006', 7);
INSERT INTO `info_hits` VALUES ('31-05-2006', 58);
INSERT INTO `info_hits` VALUES ('04-06-2006', 2);
INSERT INTO `info_hits` VALUES ('05-06-2006', 3);
INSERT INTO `info_hits` VALUES ('07-06-2006', 1);
INSERT INTO `info_hits` VALUES ('08-06-2006', 2);
INSERT INTO `info_hits` VALUES ('11-06-2006', 461);
INSERT INTO `info_hits` VALUES ('16-06-2006', 231);
INSERT INTO `info_hits` VALUES ('18-06-2006', 1);
INSERT INTO `info_hits` VALUES ('20-06-2006', 3);
INSERT INTO `info_hits` VALUES ('22-06-2006', 8);
INSERT INTO `info_hits` VALUES ('24-06-2006', 5);
INSERT INTO `info_hits` VALUES ('28-06-2006', 2);
INSERT INTO `info_hits` VALUES ('30-06-2006', 152);
INSERT INTO `info_hits` VALUES ('02-07-2006', 1);
INSERT INTO `info_hits` VALUES ('05-07-2006', 3);
INSERT INTO `info_hits` VALUES ('07-07-2006', 2);
INSERT INTO `info_hits` VALUES ('08-07-2006', 18);
INSERT INTO `info_hits` VALUES ('09-07-2006', 7);
INSERT INTO `info_hits` VALUES ('12-07-2006', 5);
INSERT INTO `info_hits` VALUES ('13-07-2006', 6);
INSERT INTO `info_hits` VALUES ('15-07-2006', 6);
INSERT INTO `info_hits` VALUES ('18-07-2006', 43);
INSERT INTO `info_hits` VALUES ('19-07-2006', 125);
INSERT INTO `info_hits` VALUES ('15-08-2006', 37);
INSERT INTO `info_hits` VALUES ('02-09-2006', 177);
INSERT INTO `info_hits` VALUES ('03-09-2006', 207);
INSERT INTO `info_hits` VALUES ('05-09-2006', 107);
INSERT INTO `info_hits` VALUES ('06-09-2006', 60);
INSERT INTO `info_hits` VALUES ('16-09-2006', 242);
INSERT INTO `info_hits` VALUES ('20-09-2006', 348);
INSERT INTO `info_hits` VALUES ('26-09-2006', 612);
INSERT INTO `info_hits` VALUES ('01-10-2006', 22);
INSERT INTO `info_hits` VALUES ('09-10-2006', 103);
INSERT INTO `info_hits` VALUES ('10-10-2006', 10);
INSERT INTO `info_hits` VALUES ('11-10-2006', 231);
INSERT INTO `info_hits` VALUES ('12-10-2006', 48);
INSERT INTO `info_hits` VALUES ('19-10-2006', 39);
INSERT INTO `info_hits` VALUES ('12-12-2006', 30);

-- --------------------------------------------------------

-- 
-- Table structure for table `info_online`
-- 

CREATE TABLE `info_online` (
  `time` int(15) NOT NULL default '0',
  `ip` varchar(40) NOT NULL default '',
  PRIMARY KEY  (`time`),
  KEY `ip` (`ip`)
) ;

-- 
-- Dumping data for table `info_online`
-- 

INSERT INTO `info_online` VALUES (1165960255, '127.0.0.1');

-- --------------------------------------------------------

-- 
-- Table structure for table `info_os`
-- 

CREATE TABLE `info_os` (
  `name` text NOT NULL,
  `count` int(11) NOT NULL default '0'
) ;

-- 
-- Dumping data for table `info_os`
-- 

INSERT INTO `info_os` VALUES ('Windows', 6044);
INSERT INTO `info_os` VALUES ('Mac', 2);
INSERT INTO `info_os` VALUES ('Linux', 0);
INSERT INTO `info_os` VALUES ('FreeBSD', 0);
INSERT INTO `info_os` VALUES ('SunOS', 0);
INSERT INTO `info_os` VALUES ('IRIX', 0);
INSERT INTO `info_os` VALUES ('BeOS', 0);
INSERT INTO `info_os` VALUES ('OS/2', 0);
INSERT INTO `info_os` VALUES ('AIX', 0);
INSERT INTO `info_os` VALUES ('Other', 3);

-- --------------------------------------------------------

-- 
-- Table structure for table `links_adv`
-- 

CREATE TABLE `links_adv` (
  `id` int(11) NOT NULL auto_increment,
  `type` text NOT NULL,
  `content` text NOT NULL,
  PRIMARY KEY  (`id`)
)  AUTO_INCREMENT=4 ;

-- 
-- Dumping data for table `links_adv`
-- 

INSERT INTO `links_adv` VALUES (1, 'header', '\r\n        \r\n        \r\n        ');
INSERT INTO `links_adv` VALUES (2, 'footer', '\r\n        \r\n        \r\n        \r\n        ');

-- --------------------------------------------------------

-- 
-- Table structure for table `links_banners`
-- 

CREATE TABLE `links_banners` (
  `id` int(11) NOT NULL auto_increment,
  `title` text NOT NULL,
  `url` text NOT NULL,
  `img` text NOT NULL,
  `date` datetime NOT NULL default '0000-00-00 00:00:00',
  `ord` int(11) NOT NULL default '0',
  `type` text NOT NULL,
  `views` int(11) NOT NULL default '0',
  `clicks` int(11) NOT NULL default '0',
  `menu_id` int(11) NOT NULL default '0',
  `menu_pos` text NOT NULL,
  PRIMARY KEY  (`id`)
)  AUTO_INCREMENT=7 ;

-- 
-- Dumping data for table `links_banners`
-- 

INSERT INTO `links_banners` VALUES (6, '��������', 'http://allomani.com/', 'http://allomani.com/allomani_banner.gif', '2006-09-26 01:11:44', 0, 'footer', 475, 0, 0, 'r');
INSERT INTO `links_banners` VALUES (4, '��������', 'http://allomani.com', 'images/adv_w_us.gif', '0000-00-00 00:00:00', 0, 'menu', 1055, 0, 3, 'r');

-- --------------------------------------------------------

-- 
-- Table structure for table `links_blocks`
-- 

CREATE TABLE `links_blocks` (
  `id` int(11) NOT NULL auto_increment,
  `title` text NOT NULL,
  `pos` text NOT NULL,
  `file` text NOT NULL,
  `ord` int(11) NOT NULL default '0',
  `active` int(11) NOT NULL default '0',
  PRIMARY KEY  (`id`),
  FULLTEXT KEY `file` (`file`),
  FULLTEXT KEY `file_2` (`file`),
  FULLTEXT KEY `file_3` (`file`),
  FULLTEXT KEY `file_4` (`file`),
  FULLTEXT KEY `file_5` (`file`),
  FULLTEXT KEY `file_6` (`file`),
  FULLTEXT KEY `file_7` (`file`),
  FULLTEXT KEY `file_8` (`file`)
)  AUTO_INCREMENT=32 ;

-- 
-- Dumping data for table `links_blocks`
-- 

INSERT INTO `links_blocks` VALUES (10, '�����', 'l', '<center><form method="POST" action="index.php">\r\n<input type=text name="keyword" size="15">\r\n<input type=hidden name="action" value="search">\r\n<input type=submit value="���">\r\n</form></center>', 5, 1);
INSERT INTO `links_blocks` VALUES (8, '������� ��������', 'r', '<b>::</b> <a href=''index.php''>�������� </a><br>\r\n<b>::</b> <a href=''index.php?action=add_url''>��� ����� </a><br>\r\n<b>::</b> <a href=''index.php?action=contactus''>������� ���</a><br>\r\n ', 1, 1);
INSERT INTO `links_blocks` VALUES (23, '����', 'r', '<p align=center>\r\n����� ������� ��� ��� ������� � ����� ����� �� ������� ������ ���� �� ������� ������ ��� ������\r\n</p>', 0, 1);
INSERT INTO `links_blocks` VALUES (22, '������ ������', 'l', '<center>\r\n<form action=index.php method=get name=fast_get>\r\n<input type=hidden name=action value=''browse''>\r\n<select name=cat onchange="document.fast_get.submit();">\r\n<option value="">���� �� ������� </option>\r\n<?\r\n$qr = mysql_query("select * from links_cats where cat=0 order by id");\r\nwhile($data = mysql_fetch_array($qr)){\r\nprint "<option value=$data[id]>$data[name]</option>";\r\n}\r\n?>\r\n</select></form><br>', 1, 1);
INSERT INTO `links_blocks` VALUES (11, '�����������', 'l', '<?\r\n$qr_title = db_query("select * from links_votes_cats  where active=1");\r\nif(db_num($qr_title)){\r\n\r\n$data_title = db_fetch($qr_title);\r\nprint "<center>$data_title[title]</center>";\r\n$qr = mysql_query("select * from links_votes where cat=$data_title[id]");\r\nprint "<form action=\\"index.php\\" method=\\"post\\">\r\n<input type=''hidden'' name=''action'' value=''vote_add''>\r\n";\r\n\r\n while ($data = mysql_fetch_array($qr)){\r\n\r\n        print "<input type=''radio'' value=''$data[id]'' name=''vote_id''>$data[title]<br>";\r\n\r\n\r\n\r\n }\r\nprint "<center><input type=''submit'' value=''�����''> <br><br><a href=''index.php?action=votes''>������� </a></center></form>";\r\n}else{\r\nprint "<center>  �� ���� ������� ����� ����� </center>";\r\n}\r\n?>', 3, 1);
INSERT INTO `links_blocks` VALUES (30, '������ ������', 'c', '<?\r\n  global $settings,$data_links, $link_votes  ;\r\n$qr_links = db_query("select * from links_links where active=1 order by (votes / votes_total) DESC limit 12");\r\n  if(db_num($qr_links)){\r\n  $c = 1;\r\n  print "<table width=100% class=browse dir=rtl><tr>";\r\n  $td_width =  100 / $settings[''rows_limit''] ;\r\n   while($data_links = db_fetch($qr_links)){\r\n\r\n\r\n\r\n        $votes=$data_links[''votes''];\r\n       $votes_total=$data_links[''votes_total''];\r\n       if($votes && $votes_total){\r\n       $link_votes = $votes/$votes_total;\r\n       }else{\r\n       $link_votes = 0 ;\r\n       }\r\n\r\n     print "<td width=''$td_width%''>" ;\r\n\r\n   run_php(get_template("browse_links"));\r\n\r\n\r\n     print " </td>";\r\n\r\n if($c >= $settings[''rows_limit'']){\r\n      print "</tr><tr>";\r\n      $c=0;\r\n         }\r\n         $c++;\r\n\r\n\r\n           }\r\n      print "</tr></table>";\r\n}else{\r\nprint "<center> �� ���� �����</center>";\r\n}\r\n?>', 2, 1);
INSERT INTO `links_blocks` VALUES (27, '������ �����', 'c', '<?\r\n  global $settings,$data_links, $link_votes  ;\r\n$qr_links = db_query("select * from links_links where active=1 order by hits DESC limit 12");\r\n  if(db_num($qr_links)){\r\n  $c = 1;\r\n  print "<table width=100% class=browse dir=rtl><tr>";\r\n  $td_width =  100 / $settings[''rows_limit''] ;\r\n   while($data_links = db_fetch($qr_links)){\r\n\r\n\r\n\r\n        $votes=$data_links[''votes''];\r\n       $votes_total=$data_links[''votes_total''];\r\n       if($votes && $votes_total){\r\n       $link_votes = $votes/$votes_total;\r\n       }else{\r\n       $link_votes = 0 ;\r\n       }\r\n\r\n     print "<td width=''$td_width%''>" ;\r\n\r\n   run_php(get_template("browse_links"));\r\n\r\n\r\n     print " </td>";\r\n\r\n if($c >= $settings[''rows_limit'']){\r\n      print "</tr><tr>";\r\n      $c=0;\r\n         }\r\n         $c++;\r\n\r\n\r\n           }\r\n      print "</tr></table>";\r\n}else{\r\nprint "<center> �� ���� �����</center>";\r\n}\r\n?>', 1, 1);
INSERT INTO `links_blocks` VALUES (4, '���������� ����', 'r', '<?\r\nglobal $counter ;\r\n\r\nprint "<p align=center>  ����� ������ ����� $counter[online_users] ���� </p>";\r\n\r\nprint "<p dir=rtl align=center>���� ����� ���  $counter[best_visit] �� : <br> $counter[best_visit_time] <br></p>";\r\n\r\n', 4, 1);
INSERT INTO `links_blocks` VALUES (29, '����� �������', 'c', '<?\r\n    global $settings,$data_links, $link_votes  ;\r\n$qr_links = db_query("select * from links_links where active=1 order by rand() DESC limit 12");\r\n  if(db_num($qr_links)){\r\n  $c = 1;\r\n  print "<table width=100% class=browse dir=rtl><tr>";\r\n  $td_width =  100 / $settings[''rows_limit''] ;\r\n   while($data_links = db_fetch($qr_links)){\r\n\r\n\r\n\r\n        $votes=$data_links[''votes''];\r\n       $votes_total=$data_links[''votes_total''];\r\n       if($votes && $votes_total){\r\n       $link_votes = $votes/$votes_total;\r\n       }else{\r\n       $link_votes = 0 ;\r\n       }\r\n\r\n     print "<td width=''$td_width%''>" ;\r\n\r\n   run_php(get_template("browse_links"));\r\n\r\n\r\n     print " </td>";\r\n\r\n if($c >= $settings[''rows_limit'']){\r\n      print "</tr><tr>";\r\n      $c=0;\r\n         }\r\n         $c++;\r\n\r\n\r\n           }\r\n      print "</tr></table>";\r\n}else{\r\nprint "<center> �� ���� �����</center>";\r\n}\r\n?>', 4, 1);
INSERT INTO `links_blocks` VALUES (31, '����� �����', 'c', '<?\r\n  global $settings,$data_links, $link_votes  ;\r\n$qr_links = db_query("select links_links.* from links_links,links_classes where links_links.class = links_classes.id and links_classes.special = 1  order by links_classes.id limit 12");\r\n  if(db_num($qr_links)){\r\n  $c = 1;\r\n  print "<table width=100% class=browse dir=rtl><tr>";\r\n  $td_width =  100 / $settings[''rows_limit''] ;\r\n   while($data_links = db_fetch($qr_links)){\r\n\r\n\r\n\r\n        $votes=$data_links[''votes''];\r\n       $votes_total=$data_links[''votes_total''];\r\n       if($votes && $votes_total){\r\n       $link_votes = $votes/$votes_total;\r\n       }else{\r\n       $link_votes = 0 ;\r\n       }\r\n\r\n     print "<td width=''$td_width%''>" ;\r\n\r\n   run_php(get_template("browse_links"));\r\n\r\n\r\n     print " </td>";\r\n\r\n if($c >= $settings[''rows_limit'']){\r\n      print "</tr><tr>";\r\n      $c=0;\r\n         }\r\n         $c++;\r\n\r\n\r\n           }\r\n      print "</tr></table>";\r\n}else{\r\nprint "<center> �� ���� �����</center>";\r\n}\r\n?>', 3, 1);

-- --------------------------------------------------------

-- 
-- Table structure for table `links_cats`
-- 

CREATE TABLE `links_cats` (
  `id` int(11) NOT NULL auto_increment,
  `name` text NOT NULL,
  `cat` int(11) NOT NULL default '0',
  PRIMARY KEY  (`id`)
)  AUTO_INCREMENT=31 ;

-- 
-- Dumping data for table `links_cats`
-- 

INSERT INTO `links_cats` VALUES (1, '������� �������', 0);
INSERT INTO `links_cats` VALUES (2, '������ ���������', 0);
INSERT INTO `links_cats` VALUES (3, '������ � �����', 0);
INSERT INTO `links_cats` VALUES (4, '����������������', 0);
INSERT INTO `links_cats` VALUES (5, '���� �������', 1);
INSERT INTO `links_cats` VALUES (6, '����� �������', 1);
INSERT INTO `links_cats` VALUES (7, '��������� � ����� �������', 1);
INSERT INTO `links_cats` VALUES (8, '���� ������', 2);
INSERT INTO `links_cats` VALUES (9, '������� ��������', 2);
INSERT INTO `links_cats` VALUES (10, '������� �����������', 2);
INSERT INTO `links_cats` VALUES (11, '����� ����� ������', 3);
INSERT INTO `links_cats` VALUES (12, '������ �����', 3);
INSERT INTO `links_cats` VALUES (13, '����� ����', 3);
INSERT INTO `links_cats` VALUES (14, '������� �������', 4);
INSERT INTO `links_cats` VALUES (15, '����� ������', 4);
INSERT INTO `links_cats` VALUES (16, '����� ������', 4);
INSERT INTO `links_cats` VALUES (28, '������� � ����� �������', 1);
INSERT INTO `links_cats` VALUES (29, '�����', 1);
INSERT INTO `links_cats` VALUES (30, '�����', 1);

-- --------------------------------------------------------

-- 
-- Table structure for table `links_classes`
-- 

CREATE TABLE `links_classes` (
  `id` int(11) NOT NULL auto_increment,
  `name` text NOT NULL,
  `before` text NOT NULL,
  `after` text NOT NULL,
  `special` int(11) NOT NULL default '0',
  PRIMARY KEY  (`id`)
)  AUTO_INCREMENT=8 ;

-- 
-- Dumping data for table `links_classes`
-- 

INSERT INTO `links_classes` VALUES (1, '���� ����', '<font color=red>', '</font>', 1);
INSERT INTO `links_classes` VALUES (3, '����', '<font color=red>', '</font>', 0);
INSERT INTO `links_classes` VALUES (4, '����', '<font color=green>', '</font>', 0);
INSERT INTO `links_classes` VALUES (5, '���� ����', '<font color=green>', '</font>', 1);
INSERT INTO `links_classes` VALUES (6, '����', '<i>', '</i>', 0);
INSERT INTO `links_classes` VALUES (7, '����', '<b>', '</b>', 0);

-- --------------------------------------------------------

-- 
-- Table structure for table `links_links`
-- 

CREATE TABLE `links_links` (
  `id` int(11) NOT NULL auto_increment,
  `name` text NOT NULL,
  `url` text NOT NULL,
  `description` text NOT NULL,
  `class` text NOT NULL,
  `cat` int(11) NOT NULL default '0',
  `active` int(11) NOT NULL default '0',
  `hits` int(11) NOT NULL default '0',
  `date` datetime NOT NULL default '0000-00-00 00:00:00',
  `votes` int(11) NOT NULL default '0',
  `votes_total` int(11) NOT NULL default '0',
  PRIMARY KEY  (`id`)
)  AUTO_INCREMENT=17 ;

-- 
-- Dumping data for table `links_links`
-- 

INSERT INTO `links_links` VALUES (2, '�������� ', 'http://allomani.com', '���� �������� ������� ��������', '1', 7, 1, 1, '2006-09-16 11:38:17', 6, 2);
INSERT INTO `links_links` VALUES (3, '����� ����', 'http://www.makki-style.com/', '    ', '5', 7, 1, 2, '2006-09-16 18:49:08', 3, 1);
INSERT INTO `links_links` VALUES (4, '������� �������', 'http://www.buhayra.com/', '  ', '0', 7, 1, 3, '2006-09-16 18:49:23', 1, 1);
INSERT INTO `links_links` VALUES (5, '������ ������', 'http://www.west4coast.com/', '     ', '4', 7, 1, 1, '2006-09-16 18:50:05', 11, 4);
INSERT INTO `links_links` VALUES (6, '����� ���������', 'http://www.creic.com.sa/', '  ', '1', 9, 1, 0, '2006-09-16 19:06:06', 0, 0);
INSERT INTO `links_links` VALUES (7, '��� ���� �������', 'http://www.abikhalil.com/', '  ', '0', 9, 1, 2, '2006-09-16 19:06:06', 6, 3);
INSERT INTO `links_links` VALUES (8, '������', 'http://test.com', '������ ������', '', 13, 0, 0, '2006-09-26 16:10:47', 0, 0);
INSERT INTO `links_links` VALUES (10, '������', '', 'r', '0', 7, 1, 0, '2006-09-26 18:41:15', 0, 0);
INSERT INTO `links_links` VALUES (11, '�����-������', '', '', '0', 5, 1, 1, '2006-09-26 18:41:43', 0, 0);
INSERT INTO `links_links` VALUES (12, '������ - ������', '', 'r', '0', 9, 1, 0, '2006-09-26 18:43:29', 0, 0);
INSERT INTO `links_links` VALUES (13, '������', '', '', '0', 5, 1, 1, '2006-09-26 19:21:32', 0, 0);
INSERT INTO `links_links` VALUES (14, 'HSBC', 'http://hsbc.com', '', '0', 8, 1, 0, '2006-10-11 04:51:45', 0, 0);
INSERT INTO `links_links` VALUES (15, '����� ������� ������', 'http://www.cibeg.com', '', '0', 8, 1, 1, '2006-10-11 04:51:45', 0, 0);
INSERT INTO `links_links` VALUES (16, '���� ����', 'http://www.tkne.net/', '', '0', 28, 1, 0, '2006-10-11 04:52:23', 0, 0);

-- --------------------------------------------------------

-- 
-- Table structure for table `links_pages`
-- 

CREATE TABLE `links_pages` (
  `id` int(11) NOT NULL auto_increment,
  `title` text NOT NULL,
  `content` text NOT NULL,
  `active` int(11) NOT NULL default '0',
  PRIMARY KEY  (`id`)
)  AUTO_INCREMENT=2 ;

-- 
-- Dumping data for table `links_pages`
-- 

INSERT INTO `links_pages` VALUES (1, '���� ������', '<center> ��� ���� ������ \r\n<?\r\nprint "�� ������� ����� ����� php " ;\r\n?>\r\n</center>', 1);

-- --------------------------------------------------------

-- 
-- Table structure for table `links_settings`
-- 

CREATE TABLE `links_settings` (
  `name` text NOT NULL,
  `value` text NOT NULL
) ;

-- 
-- Dumping data for table `links_settings`
-- 

INSERT INTO `links_settings` VALUES ('sitename', '��������');
INSERT INTO `links_settings` VALUES ('section_name', '���� �������');
INSERT INTO `links_settings` VALUES ('links_add_limit', '15');
INSERT INTO `links_settings` VALUES ('html_dir', 'ltr');
INSERT INTO `links_settings` VALUES ('header_keywords', '����� , ������');
INSERT INTO `links_settings` VALUES ('rows_limit', '3');

-- --------------------------------------------------------

-- 
-- Table structure for table `links_templates`
-- 

CREATE TABLE `links_templates` (
  `id` int(11) NOT NULL auto_increment,
  `name` text NOT NULL,
  `title` text NOT NULL,
  `content` text NOT NULL,
  PRIMARY KEY  (`id`)
)  AUTO_INCREMENT=9 ;

-- 
-- Dumping data for table `links_templates`
-- 

INSERT INTO `links_templates` VALUES (1, 'header', '������', '<HEAD>\r\n <META http-equiv=Content-Language content=ar-sa>\r\n<META http-equiv=Content-Type content="text/html; charset=windows-1256">\r\n<LINK\r\nhref="style.css" type=text/css rel=StyleSheet>\r\n</HEAD>\r\n\r\n<BODY onunload="pop_close()"  bgColor=#ffffff\r\nleftMargin=0 topMargin=0>\r\n\r\n<TABLE WIDTH=100%  dir=ltr BORDER=0 CELLPADDING=0 CELLSPACING=0>\r\n	<TR>\r\n		<TD width=22 ROWSPAN=3 width="0" bgcolor="#EAEAEA"> </TD>\r\n		\r\n		\r\n		<TD width="447">\r\n			<IMG SRC="images/8_privacyx_03.jpg" WIDTH=442 HEIGHT=310 ALT=""></TD>\r\n		<TD background="images/8_privacy2_03.jpg" width="36%"></TD>\r\n		<TD width="315">\r\n			<IMG SRC="images/8_privacyx_05.jpg" ></TD>\r\n			\r\n		<TD width="22" rowspan="3" bgcolor="#EAEAEA"> </TD>\r\n			\r\n	</TR>\r\n\r\n<TR>\r\n\r\n		\r\n		<TD colspan=3 width="95%">\r\n		\r\n		<table width=100% bgcolor="#FFFFFF">\r\n		<tr><td dir=rtl>\r\n<br>\r\n<table width=100%><tr><td width=10%>\r\n		<p class=title align=left>���� ������� </p>\r\n</td><td width=90%>\r\n			<marquee dir=rtl height=15 onmouseover="this.stop()" onmouseout="this.start()" scrollAmount="5" scrollDelay="0" direction=right  width="100%">\r\n<?\r\n$qr1=mysql_query("select * from links_links where active=1 order by id DESC limit 10 ");\r\n while($data = mysql_fetch_array($qr1))\r\n    {\r\n\r\n            print "     <img src=''images/bar_web.gif''>   <a href=''go.php?id=$data[id]'' target=''_blank''><font color=''#819E1C''>$data[name]</font></a> ";\r\n            }\r\n?>\r\n     <img src=''images/bar_web.gif''>    \r\n</marquee>\r\n</td>\r\n</tr></table>\r\n\r\n<br><br>\r\n\r\n                 \r\n        \r\n        \r\n        \r\n        \r\n        \r\n        \r\n        ');
INSERT INTO `links_templates` VALUES (8, 'links_orderby', '����� ������ ��� ...', '������� ��� : \r\n<?\r\nglobal $cat;\r\n$url_patern = "index.php?action=browse&cat=$cat" ;\r\n\r\nprint "<a href=''$url_patern&orderby=name&orderby2=asc''> <img border=0 src=''images/ord_name.gif'' alt=''����� ������''> </a>\r\n<a href=''$url_patern&orderby=hits&orderby2=desc''> <img border=0 src=''images/ord_hits.gif'' alt='' ��� �������� ''> </a>\r\n<a href=''$url_patern&orderby=votes&orderby2=desc''> <img border=0 src=''images/ord_votes.gif'' alt=''�������''> </a>\r\n<a href=''$url_patern''> <img border=0 src=''images/ord_date.gif'' alt=''����� ������� �������''> </a>\r\n" ;\r\n?>\r\n\r\n        \r\n        \r\n        \r\n        \r\n        ');
INSERT INTO `links_templates` VALUES (2, 'footer', '������', '</td></tr>\r\n		</table>\r\n		</TD>\r\n		\r\n							\r\n	</TR>\r\n	<tr>\r\n	<td colspan=3 width="100%">\r\n	\r\n	<table style="border-collapse: collapse" cellpadding="0" width=100%>\r\n	<tr>\r\n	\r\n	<td>\r\n			<IMG SRC="images/footer_10.jpg" ></td>\r\n			<td background="images/footer_11.jpg"  width="50%"> </td>\r\n			<td WIDTH=178>\r\n			<IMG SRC="images/footer_12.jpg" WIDTH=178></td>\r\n	</tr>\r\n	</table>\r\n	\r\n	\r\n	</td>\r\n	\r\n	</tr>\r\n	</TABLE>\r\n\r\n\r\n</BODY>\r\n\r\n</html>\r\n        \r\n        \r\n        \r\n        \r\n        \r\n        ');
INSERT INTO `links_templates` VALUES (3, 'block', '�������', '<center><table dir="ltr" cellSpacing="0" cellPadding="0"  border="0" id="table7">\r\n                                                                <tr>\r\n                                                                        <td width="2%" style="font-style: normal; font-variant: normal; font-weight: normal; font-size: 8pt; font-family: tahoma, arial">\r\n                                                                        <img height="16" src="images/box1.gif" width="21"></td>\r\n                                                                        <td width="95%" background="images/box2.gif" style="font-style: normal; font-variant: normal; font-weight: normal; font-size: 8pt; font-family: tahoma, arial">\r\n                                                                        <img height="16" src="images/box2.gif" width="4"></td>\r\n                                                                        <td width="3%" style="font-style: normal; font-variant: normal; font-weight: normal; font-size: 8pt; font-family: tahoma, arial">\r\n                                                                        <img height="16" src="images/box3.gif" width="21"></td>\r\n                                                                </tr>\r\n                                                                <tr>\r\n                                                                        <td background="images/box4.gif" style="font-style: normal; font-variant: normal; font-weight: normal; font-size: 8pt; font-family: tahoma, arial">\r\n                                                                        <img height="35" src="images/box4.gif" width="20"></td>\r\n                                                                        <td dir="rtl" bgColor="#F9F9F9" style="font-style: normal; font-variant: normal; font-weight: normal; font-size: 8pt; font-family: tahoma, arial">\r\n                                                                        <div align="center" dir="rtl">\r\n                                                                                <table dir="rtl" cellSpacing="4" cellPadding="0" width="100%" align="center" border="0" id="table8">\r\n                                                                                        <tr>\r\n                                                                                                <td width="100%" style="font-style: normal; font-variant: normal; font-weight: normal; font-size: 8pt; font-family: tahoma, arial">\r\n                                                                                 <p class=title align=center>{title}</p>\r\n\r\n{content}\r\n\r\n</td>\r\n                                                                                        </tr>\r\n                                                                                </table></div></td>\r\n                                                                        <td background="images/box5.gif" style="font-style: normal; font-variant: normal; font-weight: normal; font-size: 8pt; font-family: tahoma, arial">\r\n                                                                        <img height="8" src="images/box5.gif" width="21"></td>\r\n                                                                </tr>\r\n                                                                <tr>\r\n                                                                        <td style="font-style: normal; font-variant: normal; font-weight: normal; font-size: 8pt; font-family: tahoma, arial">\r\n                                                                        <img height="16" src="images/box6.gif" width="21"></td>\r\n                                                                        <td background="images/box7.gif" style="font-style: normal; font-variant: normal; font-weight: normal; font-size: 8pt; font-family: tahoma, arial">\r\n                                                                        <img height="16" src="images/box7.gif" width="3"></td>\r\n                                                                        <td style="font-style: normal; font-variant: normal; font-weight: normal; font-size: 8pt; font-family: tahoma, arial">\r\n                                                                        <img height="16" src="images/box8.gif" width="21"></td>\r\n                                                                </tr>\r\n                                                        </table><br></center>\r\n        \r\n        \r\n        ');
INSERT INTO `links_templates` VALUES (4, 'table', '�������', '<center>\r\n                                                        <table dir="ltr" cellSpacing="0" cellPadding="0"  border="0" id="table7">\r\n                                                                <tr>\r\n                                                                        <td width="2%" style="font-style: normal; font-variant: normal; font-weight: normal; font-size: 8pt; font-family: tahoma, arial">\r\n                                                                        <img height="16" src="images/box1.gif" width="21"></td>\r\n                                                                        <td width="95%" background="images/box2.gif" style="font-style: normal; font-variant: normal; font-weight: normal; font-size: 8pt; font-family: tahoma, arial">\r\n                                                                        <img height="16" src="images/box2.gif" width="4"></td>\r\n                                                                        <td width="3%" style="font-style: normal; font-variant: normal; font-weight: normal; font-size: 8pt; font-family: tahoma, arial">\r\n                                                                        <img height="16" src="images/box3.gif" width="21"></td>\r\n                                                                </tr>\r\n                                                                <tr>\r\n                                                                        <td background="images/box4.gif" style="font-style: normal; font-variant: normal; font-weight: normal; font-size: 8pt; font-family: tahoma, arial">\r\n                                                                        <img height="35" src="images/box4.gif" width="20"></td>\r\n                                                                        <td dir="rtl" bgColor="#F9F9F9" style="font-style: normal; font-variant: normal; font-weight: normal; font-size: 8pt; font-family: tahoma, arial">\r\n                                                                        <div align="center" dir="rtl">\r\n                                                                                <table dir="rtl" cellSpacing="4" cellPadding="0" width="100%" align="center" border="0" id="table8">\r\n                                                                                        <tr>\r\n                                                                                                <td width="100%" style="font-style: normal; font-variant: normal; font-weight: normal; font-size: 8pt; font-family: tahoma, arial">\r\n                                                                                   <p class=title align=center>{title}</p>\r\n\r\n                \r\n{content}\r\n\r\n</td>\r\n                                                                                        </tr>\r\n                                                                                </table></div></td>\r\n                                                                        <td background="images/box5.gif" style="font-style: normal; font-variant: normal; font-weight: normal; font-size: 8pt; font-family: tahoma, arial">\r\n                                                                        <img height="8" src="images/box5.gif" width="21"></td>\r\n                                                                </tr>\r\n                                                                <tr>\r\n                                                                        <td style="font-style: normal; font-variant: normal; font-weight: normal; font-size: 8pt; font-family: tahoma, arial">\r\n                                                                        <img height="16" src="images/box6.gif" width="21"></td>\r\n                                                                        <td background="images/box7.gif" style="font-style: normal; font-variant: normal; font-weight: normal; font-size: 8pt; font-family: tahoma, arial">\r\n                                                                        <img height="16" src="images/box7.gif" width="3"></td>\r\n                                                                        <td style="font-style: normal; font-variant: normal; font-weight: normal; font-size: 8pt; font-family: tahoma, arial">\r\n                                                                        <img height="16" src="images/box8.gif" width="21"></td>\r\n                                                                </tr>\r\n                                                        </table><br></center>\r\n        \r\n        ');
INSERT INTO `links_templates` VALUES (5, 'contactus', '������� ���', '        <center> E-Mail : <a href=''mailto:info@allomani.com''>info@allomani.com</a></center>');
INSERT INTO `links_templates` VALUES (6, 'browse_links', '���� �������', '<?\r\n  global $data_links,$link_votes ;\r\n\r\n $link_title = "����� : $data_links[name] \\n ����� ������� : ".substr($data_links[''date''],0,10)."\\n������� : $link_votes / 5";\r\n$link_title .= "\\n��� �������� : $data_links[hits]" ;\r\n\r\nif(trim($data_links[''description''])){\r\n                $link_title .= "\\n����� : ".trim($data_links[''description'']);\r\n                }\r\n\r\n\r\nprint "<table width=100% style=\\"border-collapse: collapse; \\"> <tr><td width=11 background=''images/br_right.gif''></td><td bgcolor=''#FFFFFF''><a href=''go.php?id=$data_links[id]'' target=''_blank'' title=''$link_title''>".get_link_class($data_links[''class''],$data_links[''name''])."</a></td><td width=32 bgcolor=''#FFFFFF''><a href=''javascript:add2fav($data_links[id])''><img src=''images/add2fav.gif'' border=0 alt=''����� ��� �������''></a><a href=''javascript:vote_link($data_links[id])''><img src=''images/vote.gif'' border=0 alt=''����� ������ ''></a></td><td width=11 background=''images/br_left.gif''></td></tr></table>";\r\n        \r\n        ?>\r\n        \r\n        \r\n        \r\n        \r\n        \r\n        \r\n        \r\n        \r\n        \r\n        \r\n        \r\n        \r\n        \r\n        \r\n        \r\n        \r\n        \r\n        \r\n        \r\n        \r\n        \r\n        \r\n        \r\n        \r\n        \r\n        \r\n        \r\n        \r\n        \r\n        \r\n        \r\n        \r\n        ');
INSERT INTO `links_templates` VALUES (7, 'browse_cats', '���� �������', '       <?\r\nglobal $data_cats,$links_count;\r\n\r\n print "<table width=100% style=\\"border-collapse: collapse; \\"> <tr><td width=11><img src=''images/br_right.gif''></td><td bgcolor=''#FFFFFF''><a href=''index.php?action=browse&cat=$data_cats[id]'' title=''��� ������� : $links_count''>$data_cats[name]</a>"; \r\nif($links_count){\r\nprint " <font size=1>($links_count)</font>" ;\r\n}\r\nprint "</td><td width=11><img src=''images/br_left.gif'' ></td></tr></table>";\r\n?>\r\n        \r\n        \r\n        \r\n        \r\n        \r\n        \r\n        ');

-- --------------------------------------------------------

-- 
-- Table structure for table `links_user`
-- 

CREATE TABLE `links_user` (
  `id` int(11) NOT NULL auto_increment,
  `username` text NOT NULL,
  `password` text NOT NULL,
  `email` text NOT NULL,
  `group_id` int(11) NOT NULL default '0',
  `permisions` text NOT NULL,
  `permisions_videos` text NOT NULL,
  `perm_votes` int(11) NOT NULL default '0',
  `perm_templates` int(11) NOT NULL default '0',
  `perm_blocks` int(11) NOT NULL default '0',
  `perm_adv` int(11) NOT NULL default '0',
  `perm_news` int(11) NOT NULL default '0',
  PRIMARY KEY  (`id`)
)  AUTO_INCREMENT=10 ;

-- 
-- Dumping data for table `links_user`
-- 

INSERT INTO `links_user` VALUES (1, 'admin', 'admin', 'info@allomani.com', 1, '', '', 0, 0, 0, 0, 0);
INSERT INTO `links_user` VALUES (9, 'mod', 'mod', 'info@allomani.com', 2, '', '', 1, 0, 0, 1, 1);

-- --------------------------------------------------------

-- 
-- Table structure for table `links_votes`
-- 

CREATE TABLE `links_votes` (
  `id` int(11) NOT NULL auto_increment,
  `title` text NOT NULL,
  `cnt` int(11) NOT NULL default '0',
  `cat` int(11) NOT NULL default '0',
  PRIMARY KEY  (`id`)
)  AUTO_INCREMENT=4 ;

-- 
-- Dumping data for table `links_votes`
-- 

INSERT INTO `links_votes` VALUES (1, '�����', 4, 1);
INSERT INTO `links_votes` VALUES (2, '���', 1, 1);
INSERT INTO `links_votes` VALUES (3, '���', 1, 1);

-- --------------------------------------------------------

-- 
-- Table structure for table `links_votes_cats`
-- 

CREATE TABLE `links_votes_cats` (
  `id` int(11) NOT NULL auto_increment,
  `title` text NOT NULL,
  `active` int(11) NOT NULL default '0',
  PRIMARY KEY  (`id`)
)  AUTO_INCREMENT=2 ;

-- 
-- Dumping data for table `links_votes_cats`
-- 

INSERT INTO `links_votes_cats` VALUES (1, '�� ���� �� ������ �', 1);
